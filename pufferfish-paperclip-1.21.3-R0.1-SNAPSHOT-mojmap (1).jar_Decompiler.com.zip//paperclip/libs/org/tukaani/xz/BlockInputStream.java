package paperclip.libs.org.tukaani.xz;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import paperclip.libs.org.tukaani.xz.check.Check;
import paperclip.libs.org.tukaani.xz.common.DecoderUtil;

class BlockInputStream extends InputStream {
   private final InputStream in;
   private final DataInputStream inData;
   private final CountingInputStream inCounted;
   private InputStream filterChain;
   private final Check check;
   private long uncompressedSizeInHeader = -1L;
   private long compressedSizeInHeader = -1L;
   private long compressedSizeLimit;
   private final int headerSize;
   private long uncompressedSize = 0L;
   private boolean endReached = false;

   public BlockInputStream(InputStream var1, Check var2, int var3, long var4, long var6) throws IOException, IndexIndicatorException {
      this.in = var1;
      this.check = var2;
      this.inData = new DataInputStream(var1);
      byte[] var8 = new byte[1024];
      this.inData.readFully(var8, 0, 1);
      if (var8[0] == 0) {
         throw new IndexIndicatorException();
      } else {
         this.headerSize = 4 * ((var8[0] & 255) + 1);
         this.inData.readFully(var8, 1, this.headerSize - 1);
         if (!DecoderUtil.isCRC32Valid(var8, 0, this.headerSize - 4, this.headerSize - 4)) {
            throw new CorruptedInputException("XZ Block Header is corrupt");
         } else if ((var8[1] & 60) != 0) {
            throw new UnsupportedOptionsException("Unsupported options in XZ Block Header");
         } else {
            int var9 = (var8[1] & 3) + 1;
            long[] var10 = new long[var9];
            byte[][] var11 = new byte[var9][];
            ByteArrayInputStream var12 = new ByteArrayInputStream(var8, 2, this.headerSize - 6);

            int var13;
            long var14;
            try {
               this.compressedSizeLimit = 9223372036854775804L - (long)this.headerSize - (long)var2.getSize();
               if ((var8[1] & 64) != 0) {
                  this.compressedSizeInHeader = DecoderUtil.decodeVLI(var12);
                  if (this.compressedSizeInHeader == 0L || this.compressedSizeInHeader > this.compressedSizeLimit) {
                     throw new CorruptedInputException();
                  }

                  this.compressedSizeLimit = this.compressedSizeInHeader;
               }

               if ((var8[1] & 128) != 0) {
                  this.uncompressedSizeInHeader = DecoderUtil.decodeVLI(var12);
               }

               for(var13 = 0; var13 < var9; ++var13) {
                  var10[var13] = DecoderUtil.decodeVLI(var12);
                  var14 = DecoderUtil.decodeVLI(var12);
                  if (var14 > (long)var12.available()) {
                     throw new CorruptedInputException();
                  }

                  var11[var13] = new byte[(int)var14];
                  var12.read(var11[var13]);
               }
            } catch (IOException var16) {
               throw new CorruptedInputException("XZ Block Header is corrupt");
            }

            for(var13 = var12.available(); var13 > 0; --var13) {
               if (var12.read() != 0) {
                  throw new UnsupportedOptionsException("Unsupported options in XZ Block Header");
               }
            }

            if (var4 != -1L) {
               var13 = this.headerSize + var2.getSize();
               if ((long)var13 >= var4) {
                  throw new CorruptedInputException("XZ Index does not match a Block Header");
               }

               var14 = var4 - (long)var13;
               if (var14 > this.compressedSizeLimit || this.compressedSizeInHeader != -1L && this.compressedSizeInHeader != var14) {
                  throw new CorruptedInputException("XZ Index does not match a Block Header");
               }

               if (this.uncompressedSizeInHeader != -1L && this.uncompressedSizeInHeader != var6) {
                  throw new CorruptedInputException("XZ Index does not match a Block Header");
               }

               this.compressedSizeLimit = var14;
               this.compressedSizeInHeader = var14;
               this.uncompressedSizeInHeader = var6;
            }

            FilterDecoder[] var17 = new FilterDecoder[var10.length];

            int var18;
            for(var18 = 0; var18 < var17.length; ++var18) {
               if (var10[var18] == 33L) {
                  var17[var18] = new LZMA2Decoder(var11[var18]);
               } else if (var10[var18] == 3L) {
                  var17[var18] = new DeltaDecoder(var11[var18]);
               } else {
                  if (!BCJDecoder.isBCJFilterID(var10[var18])) {
                     throw new UnsupportedOptionsException("Unknown Filter ID " + var10[var18]);
                  }

                  var17[var18] = new BCJDecoder(var10[var18], var11[var18]);
               }
            }

            RawCoder.validate(var17);
            if (var3 >= 0) {
               var18 = 0;

               for(int var15 = 0; var15 < var17.length; ++var15) {
                  var18 += var17[var15].getMemoryUsage();
               }

               if (var18 > var3) {
                  throw new MemoryLimitException(var18, var3);
               }
            }

            this.inCounted = new CountingInputStream(var1);
            this.filterChain = this.inCounted;

            for(var18 = var17.length - 1; var18 >= 0; --var18) {
               this.filterChain = var17[var18].getInputStream(this.filterChain);
            }

         }
      }
   }

   public int read() throws IOException {
      byte[] var1 = new byte[1];
      return this.read(var1, 0, 1) == -1 ? -1 : var1[0] & 255;
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      if (this.endReached) {
         return -1;
      } else {
         int var4 = this.filterChain.read(var1, var2, var3);
         if (var4 <= 0) {
            if (var4 == -1) {
               this.validate();
               this.endReached = true;
            }
         } else {
            this.check.update(var1, var2, var4);
            this.uncompressedSize += (long)var4;
            long var5 = this.inCounted.getSize();
            if (var5 < 0L || var5 > this.compressedSizeLimit || this.uncompressedSize < 0L || this.uncompressedSizeInHeader != -1L && this.uncompressedSize > this.uncompressedSizeInHeader) {
               throw new CorruptedInputException();
            }

            if (var4 < var3 || this.uncompressedSize == this.uncompressedSizeInHeader) {
               if (this.filterChain.read() != -1) {
                  throw new CorruptedInputException();
               }

               this.validate();
               this.endReached = true;
            }
         }

         return var4;
      }
   }

   private void validate() throws IOException {
      long var1 = this.inCounted.getSize();
      if (this.compressedSizeInHeader != -1L && this.compressedSizeInHeader != var1 || this.uncompressedSizeInHeader != -1L && this.uncompressedSizeInHeader != this.uncompressedSize) {
         throw new CorruptedInputException();
      } else {
         do {
            if ((var1++ & 3L) == 0L) {
               byte[] var3 = new byte[this.check.getSize()];
               this.inData.readFully(var3);
               if (!Arrays.equals(this.check.finish(), var3)) {
                  throw new CorruptedInputException("Integrity check (" + this.check.getName() + ") does not match");
               }

               return;
            }
         } while(this.inData.readUnsignedByte() == 0);

         throw new CorruptedInputException();
      }
   }

   public int available() throws IOException {
      return this.filterChain.available();
   }

   public long getUnpaddedSize() {
      return (long)this.headerSize + this.inCounted.getSize() + (long)this.check.getSize();
   }

   public long getUncompressedSize() {
      return this.uncompressedSize;
   }
}
