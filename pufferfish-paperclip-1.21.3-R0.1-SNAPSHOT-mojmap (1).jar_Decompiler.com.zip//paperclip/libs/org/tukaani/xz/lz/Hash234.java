package paperclip.libs.org.tukaani.xz.lz;

final class Hash234 extends CRC32Hash {
   private static final int HASH_2_SIZE = 1024;
   private static final int HASH_2_MASK = 1023;
   private static final int HASH_3_SIZE = 65536;
   private static final int HASH_3_MASK = 65535;
   private final int hash4Mask;
   private final int[] hash2Table = new int[1024];
   private final int[] hash3Table = new int[65536];
   private final int[] hash4Table;
   private int hash2Value = 0;
   private int hash3Value = 0;
   private int hash4Value = 0;

   static int getHash4Size(int var0) {
      int var1 = var0 - 1;
      var1 |= var1 >>> 1;
      var1 |= var1 >>> 2;
      var1 |= var1 >>> 4;
      var1 |= var1 >>> 8;
      var1 >>>= 1;
      var1 |= 65535;
      if (var1 > 16777216) {
         var1 >>>= 1;
      }

      return var1 + 1;
   }

   static int getMemoryUsage(int var0) {
      return (66560 + getHash4Size(var0)) / 256 + 4;
   }

   Hash234(int var1) {
      this.hash4Table = new int[getHash4Size(var1)];
      this.hash4Mask = this.hash4Table.length - 1;
   }

   void calcHashes(byte[] var1, int var2) {
      int var3 = crcTable[var1[var2] & 255] ^ var1[var2 + 1] & 255;
      this.hash2Value = var3 & 1023;
      var3 ^= (var1[var2 + 2] & 255) << 8;
      this.hash3Value = var3 & '\uffff';
      var3 ^= crcTable[var1[var2 + 3] & 255] << 5;
      this.hash4Value = var3 & this.hash4Mask;
   }

   int getHash2Pos() {
      return this.hash2Table[this.hash2Value];
   }

   int getHash3Pos() {
      return this.hash3Table[this.hash3Value];
   }

   int getHash4Pos() {
      return this.hash4Table[this.hash4Value];
   }

   void updateTables(int var1) {
      this.hash2Table[this.hash2Value] = var1;
      this.hash3Table[this.hash3Value] = var1;
      this.hash4Table[this.hash4Value] = var1;
   }

   void normalize(int var1) {
      LZEncoder.normalize(this.hash2Table, var1);
      LZEncoder.normalize(this.hash3Table, var1);
      LZEncoder.normalize(this.hash4Table, var1);
   }
}
