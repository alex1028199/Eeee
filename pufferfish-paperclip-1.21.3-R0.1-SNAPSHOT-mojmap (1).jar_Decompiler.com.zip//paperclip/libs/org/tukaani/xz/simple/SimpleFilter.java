package paperclip.libs.org.tukaani.xz.simple;

public interface SimpleFilter {
   int code(byte[] var1, int var2, int var3);
}
