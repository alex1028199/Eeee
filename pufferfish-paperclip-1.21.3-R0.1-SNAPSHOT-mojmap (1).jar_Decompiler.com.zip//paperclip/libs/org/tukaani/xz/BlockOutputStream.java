package paperclip.libs.org.tukaani.xz;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import paperclip.libs.org.tukaani.xz.check.Check;
import paperclip.libs.org.tukaani.xz.common.EncoderUtil;

class BlockOutputStream extends FinishableOutputStream {
   private final OutputStream out;
   private final CountingOutputStream outCounted;
   private FinishableOutputStream filterChain;
   private final Check check;
   private final int headerSize;
   private final long compressedSizeLimit;
   private long uncompressedSize = 0L;

   public BlockOutputStream(OutputStream var1, FilterEncoder[] var2, Check var3) throws IOException {
      this.out = var1;
      this.check = var3;
      this.outCounted = new CountingOutputStream(var1);
      this.filterChain = this.outCounted;

      for(int var4 = var2.length - 1; var4 >= 0; --var4) {
         this.filterChain = var2[var4].getOutputStream(this.filterChain);
      }

      ByteArrayOutputStream var7 = new ByteArrayOutputStream();
      var7.write(0);
      var7.write(var2.length - 1);

      for(int var5 = 0; var5 < var2.length; ++var5) {
         EncoderUtil.encodeVLI(var7, var2[var5].getFilterID());
         byte[] var6 = var2[var5].getFilterProps();
         EncoderUtil.encodeVLI(var7, (long)var6.length);
         var7.write(var6);
      }

      while((var7.size() & 3) != 0) {
         var7.write(0);
      }

      byte[] var8 = var7.toByteArray();
      this.headerSize = var8.length + 4;
      if (this.headerSize > 1024) {
         throw new UnsupportedOptionsException();
      } else {
         var8[0] = (byte)(var8.length / 4);
         var1.write(var8);
         EncoderUtil.writeCRC32(var1, var8);
         this.compressedSizeLimit = 9223372036854775804L - (long)this.headerSize - (long)var3.getSize();
      }
   }

   public void write(int var1) throws IOException {
      byte[] var2 = new byte[]{(byte)var1};
      this.write(var2, 0, 1);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      this.filterChain.write(var1, var2, var3);
      this.check.update(var1, var2, var3);
      this.uncompressedSize += (long)var3;
      this.validate();
   }

   public void flush() throws IOException {
      this.filterChain.flush();
      this.validate();
   }

   public void finish() throws IOException {
      this.filterChain.finish();
      this.validate();

      for(long var1 = this.outCounted.getSize(); (var1 & 3L) != 0L; ++var1) {
         this.out.write(0);
      }

      this.out.write(this.check.finish());
   }

   private void validate() throws IOException {
      long var1 = this.outCounted.getSize();
      if (var1 < 0L || var1 > this.compressedSizeLimit || this.uncompressedSize < 0L) {
         throw new XZIOException("XZ Stream has grown too big");
      }
   }

   public long getUnpaddedSize() {
      return (long)this.headerSize + this.outCounted.getSize() + (long)this.check.getSize();
   }

   public long getUncompressedSize() {
      return this.uncompressedSize;
   }
}
