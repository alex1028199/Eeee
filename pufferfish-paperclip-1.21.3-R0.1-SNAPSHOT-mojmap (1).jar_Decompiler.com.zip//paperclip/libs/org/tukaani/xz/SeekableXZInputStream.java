package paperclip.libs.org.tukaani.xz;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import paperclip.libs.org.tukaani.xz.check.Check;
import paperclip.libs.org.tukaani.xz.common.DecoderUtil;
import paperclip.libs.org.tukaani.xz.common.StreamFlags;
import paperclip.libs.org.tukaani.xz.index.BlockInfo;
import paperclip.libs.org.tukaani.xz.index.IndexDecoder;

public class SeekableXZInputStream extends SeekableInputStream {
   private SeekableInputStream in;
   private final int memoryLimit;
   private int indexMemoryUsage;
   private final ArrayList streams;
   private IndexDecoder index;
   private int checkTypes;
   private Check check;
   private BlockInputStream blockDecoder;
   private long uncompressedSize;
   private long largestBlockSize;
   private long curPos;
   private long seekPos;
   private boolean seekNeeded;
   private boolean endReached;
   private IOException exception;
   // $FF: synthetic field
   static final boolean $assertionsDisabled;

   public SeekableXZInputStream(SeekableInputStream var1) throws IOException {
      this(var1, -1);
   }

   public SeekableXZInputStream(SeekableInputStream var1, int var2) throws IOException {
      this.indexMemoryUsage = 0;
      this.streams = new ArrayList();
      this.checkTypes = 0;
      this.blockDecoder = null;
      this.uncompressedSize = 0L;
      this.largestBlockSize = 0L;
      this.curPos = 0L;
      this.seekNeeded = false;
      this.endReached = false;
      this.exception = null;
      this.in = var1;
      DataInputStream var3 = new DataInputStream(var1);
      var1.seek(0L);
      byte[] var4 = new byte[XZ.HEADER_MAGIC.length];
      var3.readFully(var4);
      if (!Arrays.equals(var4, XZ.HEADER_MAGIC)) {
         throw new XZFormatException();
      } else {
         long var14 = var1.length();
         if ((var14 & 3L) != 0L) {
            throw new CorruptedInputException("XZ file size is not a multiple of 4 bytes");
         } else {
            byte[] var6 = new byte[12];
            long var7 = 0L;

            while(true) {
               while(var14 > 0L) {
                  if (var14 < 12L) {
                     throw new CorruptedInputException();
                  }

                  var1.seek(var14 - 12L);
                  var3.readFully(var6);
                  if (var6[8] == 0 && var6[9] == 0 && var6[10] == 0 && var6[11] == 0) {
                     var7 += 4L;
                     var14 -= 4L;
                  } else {
                     var14 -= 12L;
                     StreamFlags var9 = DecoderUtil.decodeStreamFooter(var6);
                     if (var9.backwardSize >= var14) {
                        throw new CorruptedInputException("Backward Size in XZ Stream Footer is too big");
                     }

                     this.check = Check.getInstance(var9.checkType);
                     this.checkTypes |= 1 << var9.checkType;
                     var1.seek(var14 - var9.backwardSize);

                     try {
                        this.index = new IndexDecoder(var1, var9, var7, var2);
                     } catch (MemoryLimitException var13) {
                        if (!$assertionsDisabled && var2 < 0) {
                           throw new AssertionError();
                        }

                        throw new MemoryLimitException(var13.getMemoryNeeded() + this.indexMemoryUsage, var2 + this.indexMemoryUsage);
                     }

                     this.indexMemoryUsage += this.index.getMemoryUsage();
                     if (var2 >= 0) {
                        var2 -= this.index.getMemoryUsage();
                        if (!$assertionsDisabled && var2 < 0) {
                           throw new AssertionError();
                        }
                     }

                     if (this.largestBlockSize < this.index.getLargestBlockSize()) {
                        this.largestBlockSize = this.index.getLargestBlockSize();
                     }

                     long var10 = this.index.getStreamSize() - 12L;
                     if (var14 < var10) {
                        throw new CorruptedInputException("XZ Index indicates too big compressed size for the XZ Stream");
                     }

                     var14 -= var10;
                     var1.seek(var14);
                     var3.readFully(var6);
                     StreamFlags var12 = DecoderUtil.decodeStreamHeader(var6);
                     if (!DecoderUtil.areStreamFlagsEqual(var12, var9)) {
                        throw new CorruptedInputException("XZ Stream Footer does not match Stream Header");
                     }

                     this.uncompressedSize += this.index.getUncompressedSize();
                     if (this.uncompressedSize < 0L) {
                        throw new UnsupportedOptionsException("XZ file is too big");
                     }

                     this.streams.add(this.index);
                     var7 = 0L;
                  }
               }

               if (!$assertionsDisabled && var14 != 0L) {
                  throw new AssertionError();
               }

               this.memoryLimit = var2;
               return;
            }
         }
      }
   }

   public int getCheckTypes() {
      return this.checkTypes;
   }

   public int getIndexMemoryUsage() {
      return this.indexMemoryUsage;
   }

   public long getLargestBlockSize() {
      return this.largestBlockSize;
   }

   public int read() throws IOException {
      byte[] var1 = new byte[1];
      return this.read(var1, 0, 1) == -1 ? -1 : var1[0] & 255;
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      if (var2 >= 0 && var3 >= 0 && var2 + var3 >= 0 && var2 + var3 <= var1.length) {
         if (var3 == 0) {
            return 0;
         } else if (this.in == null) {
            throw new XZIOException("Stream closed");
         } else if (this.exception != null) {
            throw this.exception;
         } else {
            int var4 = 0;

            try {
               if (this.seekNeeded) {
                  this.seek();
               }

               if (this.endReached) {
                  return -1;
               }

               while(var3 > 0) {
                  if (this.blockDecoder == null) {
                     this.seek();
                     if (this.endReached) {
                        break;
                     }
                  }

                  int var7 = this.blockDecoder.read(var1, var2, var3);
                  if (var7 > 0) {
                     this.curPos += (long)var7;
                     var4 += var7;
                     var2 += var7;
                     var3 -= var7;
                  } else if (var7 == -1) {
                     this.blockDecoder = null;
                  }
               }
            } catch (IOException var6) {
               Object var5 = var6;
               if (var6 instanceof EOFException) {
                  var5 = new CorruptedInputException();
               }

               this.exception = (IOException)var5;
               if (var4 == 0) {
                  throw var5;
               }
            }

            return var4;
         }
      } else {
         throw new IndexOutOfBoundsException();
      }
   }

   public int available() throws IOException {
      if (this.in == null) {
         throw new XZIOException("Stream closed");
      } else if (this.exception != null) {
         throw this.exception;
      } else {
         return !this.endReached && !this.seekNeeded && this.blockDecoder != null ? this.blockDecoder.available() : 0;
      }
   }

   public void close() throws IOException {
      if (this.in != null) {
         try {
            this.in.close();
         } finally {
            this.in = null;
         }
      }

   }

   public long length() {
      return this.uncompressedSize;
   }

   public long position() throws IOException {
      if (this.in == null) {
         throw new XZIOException("Stream closed");
      } else {
         return this.seekNeeded ? this.seekPos : this.curPos;
      }
   }

   public void seek(long var1) throws IOException {
      if (this.in == null) {
         throw new XZIOException("Stream closed");
      } else if (var1 < 0L) {
         throw new XZIOException("Negative seek position: " + var1);
      } else {
         this.seekPos = var1;
         this.seekNeeded = true;
      }
   }

   private void seek() throws IOException {
      if (!this.seekNeeded) {
         if (this.index.hasNext()) {
            BlockInfo var9 = this.index.getNext();
            this.initBlockDecoder(var9);
            return;
         }

         this.seekPos = this.curPos;
      }

      this.seekNeeded = false;
      if (this.seekPos >= this.uncompressedSize) {
         this.curPos = this.seekPos;
         this.blockDecoder = null;
         this.endReached = true;
      } else {
         this.endReached = false;
         int var1 = this.streams.size();
         if (!$assertionsDisabled && var1 < 1) {
            throw new AssertionError();
         } else {
            long var2 = 0L;
            long var4 = 0L;

            do {
               --var1;
               this.index = (IndexDecoder)this.streams.get(var1);
               if (var2 + this.index.getUncompressedSize() > this.seekPos) {
                  BlockInfo var6 = this.index.locate(this.seekPos - var2);
                  if (!$assertionsDisabled && (var6.compressedOffset & 3L) != 0L) {
                     throw new AssertionError(var6.compressedOffset);
                  } else {
                     var6.compressedOffset += var4;
                     var6.uncompressedOffset += var2;
                     if (!$assertionsDisabled && this.seekPos < var6.uncompressedOffset) {
                        throw new AssertionError();
                     } else if (!$assertionsDisabled && this.seekPos >= var6.uncompressedOffset + var6.uncompressedSize) {
                        throw new AssertionError();
                     } else {
                        if (this.curPos <= var6.uncompressedOffset || this.curPos > this.seekPos) {
                           this.in.seek(var6.compressedOffset);
                           this.check = Check.getInstance(var6.streamFlags.checkType);
                           this.initBlockDecoder(var6);
                           this.curPos = var6.uncompressedOffset;
                        }

                        if (this.seekPos > this.curPos) {
                           long var7 = this.seekPos - this.curPos;
                           if (this.blockDecoder.skip(var7) != var7) {
                              throw new CorruptedInputException();
                           }
                        }

                        this.curPos = this.seekPos;
                        return;
                     }
                  }
               }

               var2 += this.index.getUncompressedSize();
               var4 += this.index.getStreamAndPaddingSize();
            } while($assertionsDisabled || (var4 & 3L) == 0L);

            throw new AssertionError();
         }
      }
   }

   private void initBlockDecoder(BlockInfo var1) throws IOException {
      try {
         this.blockDecoder = null;
         this.blockDecoder = new BlockInputStream(this.in, this.check, this.memoryLimit, var1.unpaddedSize, var1.uncompressedSize);
      } catch (MemoryLimitException var3) {
         if (!$assertionsDisabled && this.memoryLimit < 0) {
            throw new AssertionError();
         } else {
            throw new MemoryLimitException(var3.getMemoryNeeded() + this.indexMemoryUsage, this.memoryLimit + this.indexMemoryUsage);
         }
      } catch (IndexIndicatorException var4) {
         throw new CorruptedInputException();
      }
   }

   static {
      $assertionsDisabled = !SeekableXZInputStream.class.desiredAssertionStatus();
   }
}
