package paperclip.libs.org.tukaani.xz;

import java.io.IOException;
import java.io.InputStream;

public abstract class FilterOptions implements Cloneable {
   public static int getEncoderMemoryUsage(FilterOptions[] var0) {
      int var1 = 0;

      for(int var2 = 0; var2 < var0.length; ++var2) {
         var1 += var0[var2].getEncoderMemoryUsage();
      }

      return var1;
   }

   public static int getDecoderMemoryUsage(FilterOptions[] var0) {
      int var1 = 0;

      for(int var2 = 0; var2 < var0.length; ++var2) {
         var1 += var0[var2].getDecoderMemoryUsage();
      }

      return var1;
   }

   public abstract int getEncoderMemoryUsage();

   public abstract FinishableOutputStream getOutputStream(FinishableOutputStream var1);

   public abstract int getDecoderMemoryUsage();

   public abstract InputStream getInputStream(InputStream var1) throws IOException;

   abstract FilterEncoder getFilterEncoder();

   FilterOptions() {
   }
}
