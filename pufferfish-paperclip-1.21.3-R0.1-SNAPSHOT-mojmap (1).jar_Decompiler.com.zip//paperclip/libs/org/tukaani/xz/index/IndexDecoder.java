package paperclip.libs.org.tukaani.xz.index;

import java.io.EOFException;
import java.io.IOException;
import java.util.zip.CRC32;
import java.util.zip.CheckedInputStream;
import paperclip.libs.org.tukaani.xz.CorruptedInputException;
import paperclip.libs.org.tukaani.xz.MemoryLimitException;
import paperclip.libs.org.tukaani.xz.SeekableInputStream;
import paperclip.libs.org.tukaani.xz.UnsupportedOptionsException;
import paperclip.libs.org.tukaani.xz.common.DecoderUtil;
import paperclip.libs.org.tukaani.xz.common.StreamFlags;

public class IndexDecoder extends IndexBase {
   private final BlockInfo info = new BlockInfo();
   private final long streamPadding;
   private final int memoryUsage;
   private final long[] unpadded;
   private final long[] uncompressed;
   private long largestBlockSize = 0L;
   private int pos = -1;
   // $FF: synthetic field
   static final boolean $assertionsDisabled;

   public IndexDecoder(SeekableInputStream var1, StreamFlags var2, long var3, int var5) throws IOException {
      super(new CorruptedInputException("XZ Index is corrupt"));
      this.info.streamFlags = var2;
      this.streamPadding = var3;
      long var6 = var1.position() + var2.backwardSize - 4L;
      CRC32 var8 = new CRC32();
      CheckedInputStream var9 = new CheckedInputStream(var1, var8);
      if (var9.read() != 0) {
         throw new CorruptedInputException("XZ Index is corrupt");
      } else {
         int var13;
         try {
            long var10 = DecoderUtil.decodeVLI(var9);
            if (var10 >= var2.backwardSize / 2L) {
               throw new CorruptedInputException("XZ Index is corrupt");
            }

            if (var10 > 2147483647L) {
               throw new UnsupportedOptionsException("XZ Index has over 2147483647 Records");
            }

            this.memoryUsage = 1 + (int)((16L * var10 + 1023L) / 1024L);
            if (var5 >= 0 && this.memoryUsage > var5) {
               throw new MemoryLimitException(this.memoryUsage, var5);
            }

            this.unpadded = new long[(int)var10];
            this.uncompressed = new long[(int)var10];
            int var12 = 0;

            for(var13 = (int)var10; var13 > 0; --var13) {
               long var14 = DecoderUtil.decodeVLI(var9);
               long var16 = DecoderUtil.decodeVLI(var9);
               if (var1.position() > var6) {
                  throw new CorruptedInputException("XZ Index is corrupt");
               }

               this.unpadded[var12] = this.blocksSum + var14;
               this.uncompressed[var12] = this.uncompressedSum + var16;
               ++var12;
               super.add(var14, var16);
               if (!$assertionsDisabled && (long)var12 != this.recordCount) {
                  throw new AssertionError();
               }

               if (this.largestBlockSize < var16) {
                  this.largestBlockSize = var16;
               }
            }
         } catch (EOFException var18) {
            throw new CorruptedInputException("XZ Index is corrupt");
         }

         int var19 = this.getIndexPaddingSize();
         if (var1.position() + (long)var19 != var6) {
            throw new CorruptedInputException("XZ Index is corrupt");
         } else {
            do {
               if (var19-- <= 0) {
                  long var11 = var8.getValue();

                  for(var13 = 0; var13 < 4; ++var13) {
                     if ((var11 >>> var13 * 8 & 255L) != (long)var1.read()) {
                        throw new CorruptedInputException("XZ Index is corrupt");
                     }
                  }

                  return;
               }
            } while(var9.read() == 0);

            throw new CorruptedInputException("XZ Index is corrupt");
         }
      }
   }

   public BlockInfo locate(long var1) {
      if (!$assertionsDisabled && var1 >= this.uncompressedSum) {
         throw new AssertionError();
      } else {
         int var3 = 0;
         int var4 = this.unpadded.length - 1;

         while(var3 < var4) {
            int var5 = var3 + (var4 - var3) / 2;
            if (this.uncompressed[var5] <= var1) {
               var3 = var5 + 1;
            } else {
               var4 = var5;
            }
         }

         this.pos = var3;
         return this.getInfo();
      }
   }

   public int getMemoryUsage() {
      return this.memoryUsage;
   }

   public long getStreamAndPaddingSize() {
      return this.getStreamSize() + this.streamPadding;
   }

   public long getUncompressedSize() {
      return this.uncompressedSum;
   }

   public long getLargestBlockSize() {
      return this.largestBlockSize;
   }

   public boolean hasNext() {
      return (long)(this.pos + 1) < this.recordCount;
   }

   public BlockInfo getNext() {
      ++this.pos;
      return this.getInfo();
   }

   private BlockInfo getInfo() {
      if (this.pos == 0) {
         this.info.compressedOffset = 0L;
         this.info.uncompressedOffset = 0L;
      } else {
         this.info.compressedOffset = this.unpadded[this.pos - 1] + 3L & -4L;
         this.info.uncompressedOffset = this.uncompressed[this.pos - 1];
      }

      this.info.unpaddedSize = this.unpadded[this.pos] - this.info.compressedOffset;
      this.info.uncompressedSize = this.uncompressed[this.pos] - this.info.uncompressedOffset;
      BlockInfo var10000 = this.info;
      var10000.compressedOffset += 12L;
      return this.info;
   }

   static {
      $assertionsDisabled = !IndexDecoder.class.desiredAssertionStatus();
   }
}
