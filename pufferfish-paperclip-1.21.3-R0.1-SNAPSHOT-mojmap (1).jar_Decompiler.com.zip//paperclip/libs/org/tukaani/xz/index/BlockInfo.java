package paperclip.libs.org.tukaani.xz.index;

import paperclip.libs.org.tukaani.xz.common.StreamFlags;

public class BlockInfo {
   public StreamFlags streamFlags;
   public long compressedOffset;
   public long uncompressedOffset;
   public long unpaddedSize;
   public long uncompressedSize;
}
