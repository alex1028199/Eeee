package paperclip.libs.org.tukaani.xz;

import java.io.InputStream;
import paperclip.libs.org.tukaani.xz.simple.ARM;
import paperclip.libs.org.tukaani.xz.simple.ARMThumb;
import paperclip.libs.org.tukaani.xz.simple.IA64;
import paperclip.libs.org.tukaani.xz.simple.PowerPC;
import paperclip.libs.org.tukaani.xz.simple.SPARC;
import paperclip.libs.org.tukaani.xz.simple.SimpleFilter;
import paperclip.libs.org.tukaani.xz.simple.X86;

class BCJDecoder extends BCJCoder implements FilterDecoder {
   private final long filterID;
   private final int startOffset;
   // $FF: synthetic field
   static final boolean $assertionsDisabled;

   BCJDecoder(long var1, byte[] var3) throws UnsupportedOptionsException {
      if (!$assertionsDisabled && !isBCJFilterID(var1)) {
         throw new AssertionError();
      } else {
         this.filterID = var1;
         if (var3.length == 0) {
            this.startOffset = 0;
         } else {
            if (var3.length != 4) {
               throw new UnsupportedOptionsException("Unsupported BCJ filter properties");
            }

            int var4 = 0;

            for(int var5 = 0; var5 < 4; ++var5) {
               var4 |= (var3[var5] & 255) << var5 * 8;
            }

            this.startOffset = var4;
         }

      }
   }

   public int getMemoryUsage() {
      return SimpleInputStream.getMemoryUsage();
   }

   public InputStream getInputStream(InputStream var1) {
      Object var2 = null;
      if (this.filterID == 4L) {
         var2 = new X86(false, this.startOffset);
      } else if (this.filterID == 5L) {
         var2 = new PowerPC(false, this.startOffset);
      } else if (this.filterID == 6L) {
         var2 = new IA64(false, this.startOffset);
      } else if (this.filterID == 7L) {
         var2 = new ARM(false, this.startOffset);
      } else if (this.filterID == 8L) {
         var2 = new ARMThumb(false, this.startOffset);
      } else if (this.filterID == 9L) {
         var2 = new SPARC(false, this.startOffset);
      } else if (!$assertionsDisabled) {
         throw new AssertionError();
      }

      return new SimpleInputStream(var1, (SimpleFilter)var2);
   }

   static {
      $assertionsDisabled = !BCJDecoder.class.desiredAssertionStatus();
   }
}
