package paperclip.libs.org.tukaani.xz;

import java.io.InputStream;
import paperclip.libs.org.tukaani.xz.simple.ARM;

public class ARMOptions extends BCJOptions {
   private static final int ALIGNMENT = 4;

   public ARMOptions() {
      super(4);
   }

   public FinishableOutputStream getOutputStream(FinishableOutputStream var1) {
      return new SimpleOutputStream(var1, new ARM(true, this.startOffset));
   }

   public InputStream getInputStream(InputStream var1) {
      return new SimpleInputStream(var1, new ARM(false, this.startOffset));
   }

   FilterEncoder getFilterEncoder() {
      return new BCJEncoder(this, 7L);
   }
}
