package paperclip.libs.org.tukaani.xz;

import java.io.InputStream;
import paperclip.libs.org.tukaani.xz.simple.PowerPC;

public class PowerPCOptions extends BCJOptions {
   private static final int ALIGNMENT = 4;

   public PowerPCOptions() {
      super(4);
   }

   public FinishableOutputStream getOutputStream(FinishableOutputStream var1) {
      return new SimpleOutputStream(var1, new PowerPC(true, this.startOffset));
   }

   public InputStream getInputStream(InputStream var1) {
      return new SimpleInputStream(var1, new PowerPC(false, this.startOffset));
   }

   FilterEncoder getFilterEncoder() {
      return new BCJEncoder(this, 5L);
   }
}
