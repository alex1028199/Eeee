package paperclip.libs.org.tukaani.xz;

class IndexIndicatorException extends Exception {
   private static final long serialVersionUID = 1L;
}
