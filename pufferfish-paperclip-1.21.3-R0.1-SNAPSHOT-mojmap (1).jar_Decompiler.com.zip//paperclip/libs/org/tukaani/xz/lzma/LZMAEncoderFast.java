package paperclip.libs.org.tukaani.xz.lzma;

import paperclip.libs.org.tukaani.xz.lz.LZEncoder;
import paperclip.libs.org.tukaani.xz.lz.Matches;
import paperclip.libs.org.tukaani.xz.rangecoder.RangeEncoder;

final class LZMAEncoderFast extends LZMAEncoder {
   private static int EXTRA_SIZE_BEFORE = 1;
   private static int EXTRA_SIZE_AFTER = 272;
   private Matches matches = null;

   static int getMemoryUsage(int var0, int var1, int var2) {
      return LZEncoder.getMemoryUsage(var0, Math.max(var1, EXTRA_SIZE_BEFORE), EXTRA_SIZE_AFTER, 273, var2);
   }

   LZMAEncoderFast(RangeEncoder var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      super(var1, LZEncoder.getInstance(var5, Math.max(var6, EXTRA_SIZE_BEFORE), EXTRA_SIZE_AFTER, var7, 273, var8, var9), var2, var3, var4, var5, var7);
   }

   private boolean changePair(int var1, int var2) {
      return var1 < var2 >>> 7;
   }

   int getNextSymbol() {
      if (this.readAhead == -1) {
         this.matches = this.getMatches();
      }

      this.back = -1;
      int var1 = Math.min(this.lz.getAvail(), 273);
      if (var1 < 2) {
         return 1;
      } else {
         int var2 = 0;
         int var3 = 0;

         int var4;
         int var5;
         for(var4 = 0; var4 < 4; ++var4) {
            var5 = this.lz.getMatchLen(this.reps[var4], var1);
            if (var5 >= 2) {
               if (var5 >= this.niceLen) {
                  this.back = var4;
                  this.skip(var5 - 1);
                  return var5;
               }

               if (var5 > var2) {
                  var3 = var4;
                  var2 = var5;
               }
            }
         }

         var4 = 0;
         var5 = 0;
         if (this.matches.count > 0) {
            var4 = this.matches.len[this.matches.count - 1];
            var5 = this.matches.dist[this.matches.count - 1];
            if (var4 >= this.niceLen) {
               this.back = var5 + 4;
               this.skip(var4 - 1);
               return var4;
            }

            while(this.matches.count > 1 && var4 == this.matches.len[this.matches.count - 2] + 1 && this.changePair(this.matches.dist[this.matches.count - 2], var5)) {
               --this.matches.count;
               var4 = this.matches.len[this.matches.count - 1];
               var5 = this.matches.dist[this.matches.count - 1];
            }

            if (var4 == 2 && var5 >= 128) {
               var4 = 1;
            }
         }

         if (var2 >= 2 && (var2 + 1 >= var4 || var2 + 2 >= var4 && var5 >= 512 || var2 + 3 >= var4 && var5 >= 32768)) {
            this.back = var3;
            this.skip(var2 - 1);
            return var2;
         } else if (var4 >= 2 && var1 > 2) {
            this.matches = this.getMatches();
            int var6;
            int var7;
            if (this.matches.count > 0) {
               var6 = this.matches.len[this.matches.count - 1];
               var7 = this.matches.dist[this.matches.count - 1];
               if (var6 >= var4 && var7 < var5 || var6 == var4 + 1 && !this.changePair(var5, var7) || var6 > var4 + 1 || var6 + 1 >= var4 && var4 >= 3 && this.changePair(var7, var5)) {
                  return 1;
               }
            }

            var6 = Math.max(var4 - 1, 2);

            for(var7 = 0; var7 < 4; ++var7) {
               if (this.lz.getMatchLen(this.reps[var7], var6) == var6) {
                  return 1;
               }
            }

            this.back = var5 + 4;
            this.skip(var4 - 2);
            return var4;
         } else {
            return 1;
         }
      }
   }
}
