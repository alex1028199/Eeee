package paperclip.libs.org.tukaani.xz;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import paperclip.libs.org.tukaani.xz.check.Check;
import paperclip.libs.org.tukaani.xz.common.DecoderUtil;
import paperclip.libs.org.tukaani.xz.common.StreamFlags;
import paperclip.libs.org.tukaani.xz.index.IndexHash;

public class SingleXZInputStream extends InputStream {
   private InputStream in;
   private int memoryLimit;
   private StreamFlags streamHeaderFlags;
   private Check check;
   private BlockInputStream blockDecoder = null;
   private final IndexHash indexHash = new IndexHash();
   private boolean endReached = false;
   private IOException exception = null;

   public SingleXZInputStream(InputStream var1) throws IOException {
      this.initialize(var1, -1);
   }

   public SingleXZInputStream(InputStream var1, int var2) throws IOException {
      this.initialize(var1, var2);
   }

   SingleXZInputStream(InputStream var1, int var2, byte[] var3) throws IOException {
      this.initialize(var1, var2, var3);
   }

   private void initialize(InputStream var1, int var2) throws IOException {
      byte[] var3 = new byte[12];
      (new DataInputStream(var1)).readFully(var3);
      this.initialize(var1, var2, var3);
   }

   private void initialize(InputStream var1, int var2, byte[] var3) throws IOException {
      this.in = var1;
      this.memoryLimit = var2;
      this.streamHeaderFlags = DecoderUtil.decodeStreamHeader(var3);
      this.check = Check.getInstance(this.streamHeaderFlags.checkType);
   }

   public int getCheckType() {
      return this.streamHeaderFlags.checkType;
   }

   public String getCheckName() {
      return this.check.getName();
   }

   public int read() throws IOException {
      byte[] var1 = new byte[1];
      return this.read(var1, 0, 1) == -1 ? -1 : var1[0] & 255;
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      if (var2 >= 0 && var3 >= 0 && var2 + var3 >= 0 && var2 + var3 <= var1.length) {
         if (var3 == 0) {
            return 0;
         } else if (this.in == null) {
            throw new XZIOException("Stream closed");
         } else if (this.exception != null) {
            throw this.exception;
         } else if (this.endReached) {
            return -1;
         } else {
            int var4 = 0;

            try {
               while(var3 > 0) {
                  if (this.blockDecoder == null) {
                     try {
                        this.blockDecoder = new BlockInputStream(this.in, this.check, this.memoryLimit, -1L, -1L);
                     } catch (IndexIndicatorException var6) {
                        this.indexHash.validate(this.in);
                        this.validateStreamFooter();
                        this.endReached = true;
                        return var4 > 0 ? var4 : -1;
                     }
                  }

                  int var5 = this.blockDecoder.read(var1, var2, var3);
                  if (var5 > 0) {
                     var4 += var5;
                     var2 += var5;
                     var3 -= var5;
                  } else if (var5 == -1) {
                     this.indexHash.add(this.blockDecoder.getUnpaddedSize(), this.blockDecoder.getUncompressedSize());
                     this.blockDecoder = null;
                  }
               }
            } catch (IOException var7) {
               this.exception = var7;
               if (var4 == 0) {
                  throw var7;
               }
            }

            return var4;
         }
      } else {
         throw new IndexOutOfBoundsException();
      }
   }

   private void validateStreamFooter() throws IOException {
      byte[] var1 = new byte[12];
      (new DataInputStream(this.in)).readFully(var1);
      StreamFlags var2 = DecoderUtil.decodeStreamFooter(var1);
      if (!DecoderUtil.areStreamFlagsEqual(this.streamHeaderFlags, var2) || this.indexHash.getIndexSize() != var2.backwardSize) {
         throw new CorruptedInputException("XZ Stream Footer does not match Stream Header");
      }
   }

   public int available() throws IOException {
      if (this.in == null) {
         throw new XZIOException("Stream closed");
      } else if (this.exception != null) {
         throw this.exception;
      } else {
         return this.blockDecoder == null ? 0 : this.blockDecoder.available();
      }
   }

   public void close() throws IOException {
      if (this.in != null) {
         try {
            this.in.close();
         } finally {
            this.in = null;
         }
      }

   }
}
