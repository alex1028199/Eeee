package paperclip.libs.org.tukaani.xz;

import java.io.InputStream;
import paperclip.libs.org.tukaani.xz.simple.X86;

public class X86Options extends BCJOptions {
   private static final int ALIGNMENT = 1;

   public X86Options() {
      super(1);
   }

   public FinishableOutputStream getOutputStream(FinishableOutputStream var1) {
      return new SimpleOutputStream(var1, new X86(true, this.startOffset));
   }

   public InputStream getInputStream(InputStream var1) {
      return new SimpleInputStream(var1, new X86(false, this.startOffset));
   }

   FilterEncoder getFilterEncoder() {
      return new BCJEncoder(this, 4L);
   }
}
