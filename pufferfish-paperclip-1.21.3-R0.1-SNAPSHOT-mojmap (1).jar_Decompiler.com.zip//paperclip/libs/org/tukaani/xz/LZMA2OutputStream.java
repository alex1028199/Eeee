package paperclip.libs.org.tukaani.xz;

import java.io.DataOutputStream;
import java.io.IOException;
import paperclip.libs.org.tukaani.xz.lz.LZEncoder;
import paperclip.libs.org.tukaani.xz.lzma.LZMAEncoder;
import paperclip.libs.org.tukaani.xz.rangecoder.RangeEncoder;

class LZMA2OutputStream extends FinishableOutputStream {
   static final int COMPRESSED_SIZE_MAX = 65536;
   private FinishableOutputStream out;
   private final DataOutputStream outData;
   private final LZEncoder lz;
   private final RangeEncoder rc;
   private final LZMAEncoder lzma;
   private final int props;
   private boolean dictResetNeeded = true;
   private boolean stateResetNeeded = true;
   private boolean propsNeeded = true;
   private int pendingSize = 0;
   private boolean finished = false;
   private IOException exception = null;
   // $FF: synthetic field
   static final boolean $assertionsDisabled;

   private static int getExtraSizeBefore(int var0) {
      return 65536 > var0 ? 65536 - var0 : 0;
   }

   static int getMemoryUsage(LZMA2Options var0) {
      int var1 = var0.getDictSize();
      int var2 = getExtraSizeBefore(var1);
      return 70 + LZMAEncoder.getMemoryUsage(var0.getMode(), var1, var2, var0.getMatchFinder());
   }

   LZMA2OutputStream(FinishableOutputStream var1, LZMA2Options var2) {
      if (var1 == null) {
         throw new NullPointerException();
      } else {
         this.out = var1;
         this.outData = new DataOutputStream(var1);
         this.rc = new RangeEncoder(65536);
         int var3 = var2.getDictSize();
         int var4 = getExtraSizeBefore(var3);
         this.lzma = LZMAEncoder.getInstance(this.rc, var2.getLc(), var2.getLp(), var2.getPb(), var2.getMode(), var3, var4, var2.getNiceLen(), var2.getMatchFinder(), var2.getDepthLimit());
         this.lz = this.lzma.getLZEncoder();
         byte[] var5 = var2.getPresetDict();
         if (var5 != null && var5.length > 0) {
            this.lz.setPresetDict(var3, var5);
            this.dictResetNeeded = false;
         }

         this.props = (var2.getPb() * 5 + var2.getLp()) * 9 + var2.getLc();
      }
   }

   public void write(int var1) throws IOException {
      byte[] var2 = new byte[]{(byte)var1};
      this.write(var2, 0, 1);
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      if (var2 >= 0 && var3 >= 0 && var2 + var3 >= 0 && var2 + var3 <= var1.length) {
         if (this.exception != null) {
            throw this.exception;
         } else if (this.finished) {
            throw new XZIOException("Stream finished or closed");
         } else {
            try {
               while(var3 > 0) {
                  int var4 = this.lz.fillWindow(var1, var2, var3);
                  var2 += var4;
                  var3 -= var4;
                  this.pendingSize += var4;
                  if (this.lzma.encodeForLZMA2()) {
                     this.writeChunk();
                  }
               }

            } catch (IOException var5) {
               this.exception = var5;
               throw var5;
            }
         }
      } else {
         throw new IndexOutOfBoundsException();
      }
   }

   private void writeChunk() throws IOException {
      int var1 = this.rc.finish();
      int var2 = this.lzma.getUncompressedSize();
      if (!$assertionsDisabled && var1 <= 0) {
         throw new AssertionError(var1);
      } else if (!$assertionsDisabled && var2 <= 0) {
         throw new AssertionError(var2);
      } else {
         if (var1 + 2 < var2) {
            this.writeLZMA(var2, var1);
         } else {
            this.lzma.reset();
            var2 = this.lzma.getUncompressedSize();
            if (!$assertionsDisabled && var2 <= 0) {
               throw new AssertionError(var2);
            }

            this.writeUncompressed(var2);
         }

         this.pendingSize -= var2;
         this.lzma.resetUncompressedSize();
         this.rc.reset();
      }
   }

   private void writeLZMA(int var1, int var2) throws IOException {
      short var3;
      if (this.propsNeeded) {
         if (this.dictResetNeeded) {
            var3 = 224;
         } else {
            var3 = 192;
         }
      } else if (this.stateResetNeeded) {
         var3 = 160;
      } else {
         var3 = 128;
      }

      int var4 = var3 | var1 - 1 >>> 16;
      this.outData.writeByte(var4);
      this.outData.writeShort(var1 - 1);
      this.outData.writeShort(var2 - 1);
      if (this.propsNeeded) {
         this.outData.writeByte(this.props);
      }

      this.rc.write(this.out);
      this.propsNeeded = false;
      this.stateResetNeeded = false;
      this.dictResetNeeded = false;
   }

   private void writeUncompressed(int var1) throws IOException {
      while(var1 > 0) {
         int var2 = Math.min(var1, 65536);
         this.outData.writeByte(this.dictResetNeeded ? 1 : 2);
         this.outData.writeShort(var2 - 1);
         this.lz.copyUncompressed(this.out, var1, var2);
         var1 -= var2;
         this.dictResetNeeded = false;
      }

      this.stateResetNeeded = true;
   }

   private void writeEndMarker() throws IOException {
      if (!$assertionsDisabled && this.finished) {
         throw new AssertionError();
      } else if (this.exception != null) {
         throw this.exception;
      } else {
         this.lz.setFinishing();

         try {
            while(this.pendingSize > 0) {
               this.lzma.encodeForLZMA2();
               this.writeChunk();
            }

            this.out.write(0);
         } catch (IOException var2) {
            this.exception = var2;
            throw var2;
         }

         this.finished = true;
      }
   }

   public void flush() throws IOException {
      if (this.exception != null) {
         throw this.exception;
      } else if (this.finished) {
         throw new XZIOException("Stream finished or closed");
      } else {
         try {
            this.lz.setFlushing();

            while(this.pendingSize > 0) {
               this.lzma.encodeForLZMA2();
               this.writeChunk();
            }

            this.out.flush();
         } catch (IOException var2) {
            this.exception = var2;
            throw var2;
         }
      }
   }

   public void finish() throws IOException {
      if (!this.finished) {
         this.writeEndMarker();

         try {
            this.out.finish();
         } catch (IOException var2) {
            this.exception = var2;
            throw var2;
         }

         this.finished = true;
      }

   }

   public void close() throws IOException {
      if (this.out != null) {
         if (!this.finished) {
            try {
               this.writeEndMarker();
            } catch (IOException var2) {
            }
         }

         try {
            this.out.close();
         } catch (IOException var3) {
            if (this.exception == null) {
               this.exception = var3;
            }
         }

         this.out = null;
      }

      if (this.exception != null) {
         throw this.exception;
      }
   }

   static {
      $assertionsDisabled = !LZMA2OutputStream.class.desiredAssertionStatus();
   }
}
