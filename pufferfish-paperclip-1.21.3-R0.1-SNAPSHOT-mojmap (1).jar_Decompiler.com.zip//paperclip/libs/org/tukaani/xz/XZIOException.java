package paperclip.libs.org.tukaani.xz;

import java.io.IOException;

public class XZIOException extends IOException {
   private static final long serialVersionUID = 3L;

   public XZIOException() {
   }

   public XZIOException(String var1) {
      super(var1);
   }
}
