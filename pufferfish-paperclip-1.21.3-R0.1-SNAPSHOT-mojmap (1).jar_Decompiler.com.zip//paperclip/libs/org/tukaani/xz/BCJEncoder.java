package paperclip.libs.org.tukaani.xz;

class BCJEncoder extends BCJCoder implements FilterEncoder {
   private final BCJOptions options;
   private final long filterID;
   private final byte[] props;
   // $FF: synthetic field
   static final boolean $assertionsDisabled;

   BCJEncoder(BCJOptions var1, long var2) {
      if (!$assertionsDisabled && !isBCJFilterID(var2)) {
         throw new AssertionError();
      } else {
         int var4 = var1.getStartOffset();
         if (var4 == 0) {
            this.props = new byte[0];
         } else {
            this.props = new byte[4];

            for(int var5 = 0; var5 < 4; ++var5) {
               this.props[var5] = (byte)(var4 >>> var5 * 8);
            }
         }

         this.filterID = var2;
         this.options = (BCJOptions)var1.clone();
      }
   }

   public long getFilterID() {
      return this.filterID;
   }

   public byte[] getFilterProps() {
      return this.props;
   }

   public boolean supportsFlushing() {
      return false;
   }

   public FinishableOutputStream getOutputStream(FinishableOutputStream var1) {
      return this.options.getOutputStream(var1);
   }

   static {
      $assertionsDisabled = !BCJEncoder.class.desiredAssertionStatus();
   }
}
