package paperclip.libs.org.tukaani.xz.common;

public class StreamFlags {
   public int checkType = -1;
   public long backwardSize = -1L;
}
