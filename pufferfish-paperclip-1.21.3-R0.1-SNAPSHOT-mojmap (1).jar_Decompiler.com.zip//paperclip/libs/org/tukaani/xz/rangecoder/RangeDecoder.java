package paperclip.libs.org.tukaani.xz.rangecoder;

import java.io.DataInputStream;
import java.io.IOException;
import paperclip.libs.org.tukaani.xz.CorruptedInputException;

public final class RangeDecoder extends RangeCoder {
   private static final int INIT_SIZE = 5;
   private final byte[] buf;
   private int pos = 0;
   private int end = 0;
   private int range = 0;
   private int code = 0;

   public RangeDecoder(int var1) {
      this.buf = new byte[var1 - 5];
   }

   public void prepareInputBuffer(DataInputStream var1, int var2) throws IOException {
      if (var2 < 5) {
         throw new CorruptedInputException();
      } else if (var1.readUnsignedByte() != 0) {
         throw new CorruptedInputException();
      } else {
         this.code = var1.readInt();
         this.range = -1;
         this.pos = 0;
         this.end = var2 - 5;
         var1.readFully(this.buf, 0, this.end);
      }
   }

   public boolean isInBufferOK() {
      return this.pos <= this.end;
   }

   public boolean isFinished() {
      return this.pos == this.end && this.code == 0;
   }

   public void normalize() throws IOException {
      if ((this.range & -16777216) == 0) {
         try {
            this.code = this.code << 8 | this.buf[this.pos++] & 255;
            this.range <<= 8;
         } catch (ArrayIndexOutOfBoundsException var2) {
            throw new CorruptedInputException();
         }
      }

   }

   public int decodeBit(short[] var1, int var2) throws IOException {
      this.normalize();
      short var3 = var1[var2];
      int var4 = (this.range >>> 11) * var3;
      byte var5;
      if ((this.code ^ Integer.MIN_VALUE) < (var4 ^ Integer.MIN_VALUE)) {
         this.range = var4;
         var1[var2] = (short)(var3 + (2048 - var3 >>> 5));
         var5 = 0;
      } else {
         this.range -= var4;
         this.code -= var4;
         var1[var2] = (short)(var3 - (var3 >>> 5));
         var5 = 1;
      }

      return var5;
   }

   public int decodeBitTree(short[] var1) throws IOException {
      int var2 = 1;

      do {
         var2 = var2 << 1 | this.decodeBit(var1, var2);
      } while(var2 < var1.length);

      return var2 - var1.length;
   }

   public int decodeReverseBitTree(short[] var1) throws IOException {
      int var2 = 1;
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = this.decodeBit(var1, var2);
         var2 = var2 << 1 | var5;
         var4 |= var5 << var3++;
      } while(var2 < var1.length);

      return var4;
   }

   public int decodeDirectBits(int var1) throws IOException {
      int var2 = 0;

      do {
         this.normalize();
         this.range >>>= 1;
         int var3 = this.code - this.range >>> 31;
         this.code -= this.range & var3 - 1;
         var2 = var2 << 1 | 1 - var3;
         --var1;
      } while(var1 != 0);

      return var2;
   }
}
