package paperclip.libs.org.apache.commons.compress.archivers.ar;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import paperclip.libs.org.apache.commons.compress.archivers.ArchiveEntry;
import paperclip.libs.org.apache.commons.compress.archivers.ArchiveInputStream;
import paperclip.libs.org.apache.commons.compress.utils.ArchiveUtils;

public class ArArchiveInputStream extends ArchiveInputStream {
   private final InputStream input;
   private long offset = 0L;
   private boolean closed;
   private ArArchiveEntry currentEntry = null;
   private byte[] namebuffer = null;
   private long entryOffset = -1L;
   private final byte[] NAME_BUF = new byte[16];
   private final byte[] LAST_MODIFIED_BUF = new byte[12];
   private final byte[] ID_BUF = new byte[6];
   private final byte[] FILE_MODE_BUF = new byte[8];
   private final byte[] LENGTH_BUF = new byte[10];
   static final String BSD_LONGNAME_PREFIX = "#1/";
   private static final int BSD_LONGNAME_PREFIX_LEN = "#1/".length();
   private static final String BSD_LONGNAME_PATTERN = "^#1/\\d+";
   private static final String GNU_STRING_TABLE_NAME = "//";
   private static final String GNU_LONGNAME_PATTERN = "^/\\d+";

   public ArArchiveInputStream(InputStream pInput) {
      this.input = pInput;
      this.closed = false;
   }

   public ArArchiveEntry getNextArEntry() throws IOException {
      int read;
      if (this.currentEntry != null) {
         long entryEnd = this.entryOffset + this.currentEntry.getLength();

         while(this.offset < entryEnd) {
            read = this.read();
            if (read == -1) {
               return null;
            }
         }

         this.currentEntry = null;
      }

      byte[] expected;
      int read;
      if (this.offset == 0L) {
         byte[] expected = ArchiveUtils.toAsciiBytes("!<arch>\n");
         expected = new byte[expected.length];
         read = this.read(expected);
         if (read != expected.length) {
            throw new IOException("failed to read header. Occured at byte: " + this.getBytesRead());
         }

         for(read = 0; read < expected.length; ++read) {
            if (expected[read] != expected[read]) {
               throw new IOException("invalid header " + ArchiveUtils.toAsciiString(expected));
            }
         }
      }

      if (this.offset % 2L != 0L && this.read() < 0) {
         return null;
      } else if (this.input.available() == 0) {
         return null;
      } else {
         this.read(this.NAME_BUF);
         this.read(this.LAST_MODIFIED_BUF);
         this.read(this.ID_BUF);
         int userId = this.asInt(this.ID_BUF, true);
         this.read(this.ID_BUF);
         this.read(this.FILE_MODE_BUF);
         this.read(this.LENGTH_BUF);
         expected = ArchiveUtils.toAsciiBytes("`\n");
         byte[] realized = new byte[expected.length];
         read = this.read(realized);
         if (read != expected.length) {
            throw new IOException("failed to read entry trailer. Occured at byte: " + this.getBytesRead());
         } else {
            int nameLen;
            for(nameLen = 0; nameLen < expected.length; ++nameLen) {
               if (expected[nameLen] != realized[nameLen]) {
                  throw new IOException("invalid entry trailer. not read the content? Occured at byte: " + this.getBytesRead());
               }
            }

            this.entryOffset = this.offset;
            String temp = ArchiveUtils.toAsciiString(this.NAME_BUF).trim();
            if (isGNUStringTable(temp)) {
               this.currentEntry = this.readGNUStringTable(this.LENGTH_BUF);
               return this.getNextArEntry();
            } else {
               long len = this.asLong(this.LENGTH_BUF);
               if (temp.endsWith("/")) {
                  temp = temp.substring(0, temp.length() - 1);
               } else if (this.isGNULongName(temp)) {
                  nameLen = Integer.parseInt(temp.substring(1));
                  temp = this.getExtendedName(nameLen);
               } else if (isBSDLongName(temp)) {
                  temp = this.getBSDLongName(temp);
                  nameLen = temp.length();
                  len -= (long)nameLen;
                  this.entryOffset += (long)nameLen;
               }

               this.currentEntry = new ArArchiveEntry(temp, len, userId, this.asInt(this.ID_BUF, true), this.asInt(this.FILE_MODE_BUF, 8), this.asLong(this.LAST_MODIFIED_BUF));
               return this.currentEntry;
            }
         }
      }
   }

   private String getExtendedName(int offset) throws IOException {
      if (this.namebuffer == null) {
         throw new IOException("Cannot process GNU long filename as no // record was found");
      } else {
         for(int i = offset; i < this.namebuffer.length; ++i) {
            if (this.namebuffer[i] == 10) {
               if (this.namebuffer[i - 1] == 47) {
                  --i;
               }

               return ArchiveUtils.toAsciiString(this.namebuffer, offset, i - offset);
            }
         }

         throw new IOException("Failed to read entry: " + offset);
      }
   }

   private long asLong(byte[] input) {
      return Long.parseLong(ArchiveUtils.toAsciiString(input).trim());
   }

   private int asInt(byte[] input) {
      return this.asInt(input, 10, false);
   }

   private int asInt(byte[] input, boolean treatBlankAsZero) {
      return this.asInt(input, 10, treatBlankAsZero);
   }

   private int asInt(byte[] input, int base) {
      return this.asInt(input, base, false);
   }

   private int asInt(byte[] input, int base, boolean treatBlankAsZero) {
      String string = ArchiveUtils.toAsciiString(input).trim();
      return string.length() == 0 && treatBlankAsZero ? 0 : Integer.parseInt(string, base);
   }

   public ArchiveEntry getNextEntry() throws IOException {
      return this.getNextArEntry();
   }

   public void close() throws IOException {
      if (!this.closed) {
         this.closed = true;
         this.input.close();
      }

      this.currentEntry = null;
   }

   public int read(byte[] b, int off, int len) throws IOException {
      int toRead = len;
      if (this.currentEntry != null) {
         long entryEnd = this.entryOffset + this.currentEntry.getLength();
         if (len <= 0 || entryEnd <= this.offset) {
            return -1;
         }

         toRead = (int)Math.min((long)len, entryEnd - this.offset);
      }

      int ret = this.input.read(b, off, toRead);
      this.count(ret);
      this.offset += (long)(ret > 0 ? ret : 0);
      return ret;
   }

   public static boolean matches(byte[] signature, int length) {
      if (length < 8) {
         return false;
      } else if (signature[0] != 33) {
         return false;
      } else if (signature[1] != 60) {
         return false;
      } else if (signature[2] != 97) {
         return false;
      } else if (signature[3] != 114) {
         return false;
      } else if (signature[4] != 99) {
         return false;
      } else if (signature[5] != 104) {
         return false;
      } else if (signature[6] != 62) {
         return false;
      } else {
         return signature[7] == 10;
      }
   }

   private static boolean isBSDLongName(String name) {
      return name != null && name.matches("^#1/\\d+");
   }

   private String getBSDLongName(String bsdLongName) throws IOException {
      int nameLen = Integer.parseInt(bsdLongName.substring(BSD_LONGNAME_PREFIX_LEN));
      byte[] name = new byte[nameLen];
      int read = 0;
      boolean var5 = false;

      int readNow;
      while((readNow = this.input.read(name, read, nameLen - read)) >= 0) {
         read += readNow;
         this.count(readNow);
         if (read == nameLen) {
            break;
         }
      }

      if (read != nameLen) {
         throw new EOFException();
      } else {
         return ArchiveUtils.toAsciiString(name);
      }
   }

   private static boolean isGNUStringTable(String name) {
      return "//".equals(name);
   }

   private ArArchiveEntry readGNUStringTable(byte[] length) throws IOException {
      int bufflen = this.asInt(length);
      this.namebuffer = new byte[bufflen];
      int read = this.read(this.namebuffer, 0, bufflen);
      if (read != bufflen) {
         throw new IOException("Failed to read complete // record: expected=" + bufflen + " read=" + read);
      } else {
         return new ArArchiveEntry("//", (long)bufflen);
      }
   }

   private boolean isGNULongName(String name) {
      return name != null && name.matches("^/\\d+");
   }
}
