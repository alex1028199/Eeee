package paperclip.libs.org.apache.commons.compress.archivers.zip;

public enum Zip64Mode {
   Always,
   Never,
   AsNeeded;
}
