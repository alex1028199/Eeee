package paperclip.libs.org.apache.commons.compress.archivers.tar;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import paperclip.libs.org.apache.commons.compress.archivers.ArchiveEntry;
import paperclip.libs.org.apache.commons.compress.archivers.ArchiveInputStream;
import paperclip.libs.org.apache.commons.compress.archivers.zip.ZipEncoding;
import paperclip.libs.org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import paperclip.libs.org.apache.commons.compress.utils.ArchiveUtils;

public class TarArchiveInputStream extends ArchiveInputStream {
   private static final int SMALL_BUFFER_SIZE = 256;
   private static final int BUFFER_SIZE = 8192;
   private final byte[] SKIP_BUF;
   private final byte[] SMALL_BUF;
   private boolean hasHitEOF;
   private long entrySize;
   private long entryOffset;
   private byte[] readBuf;
   protected final TarBuffer buffer;
   private TarArchiveEntry currEntry;
   private final ZipEncoding encoding;

   public TarArchiveInputStream(InputStream is) {
      this(is, 10240, 512);
   }

   public TarArchiveInputStream(InputStream is, String encoding) {
      this(is, 10240, 512, encoding);
   }

   public TarArchiveInputStream(InputStream is, int blockSize) {
      this(is, blockSize, 512);
   }

   public TarArchiveInputStream(InputStream is, int blockSize, String encoding) {
      this(is, blockSize, 512, encoding);
   }

   public TarArchiveInputStream(InputStream is, int blockSize, int recordSize) {
      this(is, blockSize, recordSize, (String)null);
   }

   public TarArchiveInputStream(InputStream is, int blockSize, int recordSize, String encoding) {
      this.SKIP_BUF = new byte[8192];
      this.SMALL_BUF = new byte[256];
      this.buffer = new TarBuffer(is, blockSize, recordSize);
      this.readBuf = null;
      this.hasHitEOF = false;
      this.encoding = ZipEncodingHelper.getZipEncoding(encoding);
   }

   public void close() throws IOException {
      this.buffer.close();
   }

   public int getRecordSize() {
      return this.buffer.getRecordSize();
   }

   public int available() throws IOException {
      return this.entrySize - this.entryOffset > 2147483647L ? Integer.MAX_VALUE : (int)(this.entrySize - this.entryOffset);
   }

   public long skip(long numToSkip) throws IOException {
      long skip;
      int numRead;
      for(skip = numToSkip; skip > 0L; skip -= (long)numRead) {
         int realSkip = (int)(skip > (long)this.SKIP_BUF.length ? (long)this.SKIP_BUF.length : skip);
         numRead = this.read(this.SKIP_BUF, 0, realSkip);
         if (numRead == -1) {
            break;
         }
      }

      return numToSkip - skip;
   }

   public synchronized void reset() {
   }

   public TarArchiveEntry getNextTarEntry() throws IOException {
      if (this.hasHitEOF) {
         return null;
      } else {
         if (this.currEntry != null) {
            long skipped;
            for(long numToSkip = this.entrySize - this.entryOffset; numToSkip > 0L; numToSkip -= skipped) {
               skipped = this.skip(numToSkip);
               if (skipped <= 0L) {
                  throw new RuntimeException("failed to skip current tar entry");
               }
            }

            this.readBuf = null;
         }

         byte[] headerBuf = this.getRecord();
         if (this.hasHitEOF) {
            this.currEntry = null;
            return null;
         } else {
            try {
               this.currEntry = new TarArchiveEntry(headerBuf, this.encoding);
            } catch (IllegalArgumentException var6) {
               IOException ioe = new IOException("Error detected parsing the header");
               ioe.initCause(var6);
               throw ioe;
            }

            this.entryOffset = 0L;
            this.entrySize = this.currEntry.getSize();
            if (this.currEntry.isGNULongNameEntry()) {
               ByteArrayOutputStream longName = new ByteArrayOutputStream();
               boolean var9 = false;

               int length;
               while((length = this.read(this.SMALL_BUF)) >= 0) {
                  longName.write(this.SMALL_BUF, 0, length);
               }

               this.getNextEntry();
               if (this.currEntry == null) {
                  return null;
               }

               byte[] longNameData = longName.toByteArray();

               for(length = longNameData.length; length > 0 && longNameData[length - 1] == 0; --length) {
               }

               if (length != longNameData.length) {
                  byte[] l = new byte[length];
                  System.arraycopy(longNameData, 0, l, 0, length);
                  longNameData = l;
               }

               this.currEntry.setName(this.encoding.decode(longNameData));
            }

            if (this.currEntry.isPaxHeader()) {
               this.paxHeaders();
            }

            if (this.currEntry.isGNUSparse()) {
               this.readGNUSparse();
            }

            this.entrySize = this.currEntry.getSize();
            return this.currEntry;
         }
      }
   }

   private byte[] getRecord() throws IOException {
      if (this.hasHitEOF) {
         return null;
      } else {
         byte[] headerBuf = this.buffer.readRecord();
         if (headerBuf == null) {
            this.hasHitEOF = true;
         } else if (this.buffer.isEOFRecord(headerBuf)) {
            this.hasHitEOF = true;
            this.buffer.tryToConsumeSecondEOFRecord();
         }

         return this.hasHitEOF ? null : headerBuf;
      }
   }

   private void paxHeaders() throws IOException {
      Map<String, String> headers = this.parsePaxHeaders(this);
      this.getNextEntry();
      this.applyPaxHeadersToCurrentEntry(headers);
   }

   Map<String, String> parsePaxHeaders(InputStream i) throws IOException {
      HashMap headers = new HashMap();

      int ch;
      label37:
      do {
         int len = 0;

         for(int read = 0; (ch = i.read()) != -1; len += ch - 48) {
            ++read;
            if (ch == 32) {
               ByteArrayOutputStream coll = new ByteArrayOutputStream();

               while(true) {
                  if ((ch = i.read()) == -1) {
                     continue label37;
                  }

                  ++read;
                  if (ch == 61) {
                     String keyword = coll.toString("UTF-8");
                     byte[] rest = new byte[len - read];
                     int got = i.read(rest);
                     if (got != len - read) {
                        throw new IOException("Failed to read Paxheader. Expected " + (len - read) + " bytes, read " + got);
                     }

                     String value = new String(rest, 0, len - read - 1, "UTF-8");
                     headers.put(keyword, value);
                     continue label37;
                  }

                  coll.write((byte)ch);
               }
            }

            len *= 10;
         }
      } while(ch != -1);

      return headers;
   }

   private void applyPaxHeadersToCurrentEntry(Map<String, String> headers) {
      Iterator i$ = headers.entrySet().iterator();

      while(i$.hasNext()) {
         Entry<String, String> ent = (Entry)i$.next();
         String key = (String)ent.getKey();
         String val = (String)ent.getValue();
         if ("path".equals(key)) {
            this.currEntry.setName(val);
         } else if ("linkpath".equals(key)) {
            this.currEntry.setLinkName(val);
         } else if ("gid".equals(key)) {
            this.currEntry.setGroupId(Integer.parseInt(val));
         } else if ("gname".equals(key)) {
            this.currEntry.setGroupName(val);
         } else if ("uid".equals(key)) {
            this.currEntry.setUserId(Integer.parseInt(val));
         } else if ("uname".equals(key)) {
            this.currEntry.setUserName(val);
         } else if ("size".equals(key)) {
            this.currEntry.setSize(Long.parseLong(val));
         } else if ("mtime".equals(key)) {
            this.currEntry.setModTime((long)(Double.parseDouble(val) * 1000.0D));
         } else if ("SCHILY.devminor".equals(key)) {
            this.currEntry.setDevMinor(Integer.parseInt(val));
         } else if ("SCHILY.devmajor".equals(key)) {
            this.currEntry.setDevMajor(Integer.parseInt(val));
         }
      }

   }

   private void readGNUSparse() throws IOException {
      TarArchiveSparseEntry entry;
      if (this.currEntry.isExtended()) {
         do {
            byte[] headerBuf = this.getRecord();
            if (this.hasHitEOF) {
               this.currEntry = null;
               break;
            }

            entry = new TarArchiveSparseEntry(headerBuf);
         } while(entry.isExtended());
      }

   }

   public ArchiveEntry getNextEntry() throws IOException {
      return this.getNextTarEntry();
   }

   public int read(byte[] buf, int offset, int numToRead) throws IOException {
      int totalRead = 0;
      if (this.entryOffset >= this.entrySize) {
         return -1;
      } else {
         if ((long)numToRead + this.entryOffset > this.entrySize) {
            numToRead = (int)(this.entrySize - this.entryOffset);
         }

         int sz;
         if (this.readBuf != null) {
            int sz = numToRead > this.readBuf.length ? this.readBuf.length : numToRead;
            System.arraycopy(this.readBuf, 0, buf, offset, sz);
            if (sz >= this.readBuf.length) {
               this.readBuf = null;
            } else {
               sz = this.readBuf.length - sz;
               byte[] newBuf = new byte[sz];
               System.arraycopy(this.readBuf, sz, newBuf, 0, sz);
               this.readBuf = newBuf;
            }

            totalRead += sz;
            numToRead -= sz;
            offset += sz;
         }

         while(numToRead > 0) {
            byte[] rec = this.buffer.readRecord();
            if (rec == null) {
               throw new IOException("unexpected EOF with " + numToRead + " bytes unread. Occured at byte: " + this.getBytesRead());
            }

            this.count(rec.length);
            sz = numToRead;
            int recLen = rec.length;
            if (recLen > numToRead) {
               System.arraycopy(rec, 0, buf, offset, numToRead);
               this.readBuf = new byte[recLen - numToRead];
               System.arraycopy(rec, numToRead, this.readBuf, 0, recLen - numToRead);
            } else {
               sz = recLen;
               System.arraycopy(rec, 0, buf, offset, recLen);
            }

            totalRead += sz;
            numToRead -= sz;
            offset += sz;
         }

         this.entryOffset += (long)totalRead;
         return totalRead;
      }
   }

   public boolean canReadEntryData(ArchiveEntry ae) {
      if (ae instanceof TarArchiveEntry) {
         TarArchiveEntry te = (TarArchiveEntry)ae;
         return !te.isGNUSparse();
      } else {
         return false;
      }
   }

   protected final TarArchiveEntry getCurrentEntry() {
      return this.currEntry;
   }

   protected final void setCurrentEntry(TarArchiveEntry e) {
      this.currEntry = e;
   }

   protected final boolean isAtEOF() {
      return this.hasHitEOF;
   }

   protected final void setAtEOF(boolean b) {
      this.hasHitEOF = b;
   }

   public static boolean matches(byte[] signature, int length) {
      if (length < 265) {
         return false;
      } else if (ArchiveUtils.matchAsciiBuffer("ustar\u0000", signature, 257, 6) && ArchiveUtils.matchAsciiBuffer("00", signature, 263, 2)) {
         return true;
      } else if (ArchiveUtils.matchAsciiBuffer("ustar ", signature, 257, 6) && (ArchiveUtils.matchAsciiBuffer(" \u0000", signature, 263, 2) || ArchiveUtils.matchAsciiBuffer("0\u0000", signature, 263, 2))) {
         return true;
      } else {
         return ArchiveUtils.matchAsciiBuffer("ustar\u0000", signature, 257, 6) && ArchiveUtils.matchAsciiBuffer("\u0000\u0000", signature, 263, 2);
      }
   }
}
