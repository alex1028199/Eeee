package paperclip.libs.org.apache.commons.compress.compressors.gzip;

import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;
import paperclip.libs.org.apache.commons.compress.compressors.CompressorOutputStream;

public class GzipCompressorOutputStream extends CompressorOutputStream {
   private final GZIPOutputStream out;

   public GzipCompressorOutputStream(OutputStream outputStream) throws IOException {
      this.out = new GZIPOutputStream(outputStream);
   }

   public void write(int b) throws IOException {
      this.out.write(b);
   }

   public void write(byte[] b) throws IOException {
      this.out.write(b);
   }

   public void write(byte[] b, int from, int length) throws IOException {
      this.out.write(b, from, length);
   }

   public void close() throws IOException {
      this.out.close();
   }
}
