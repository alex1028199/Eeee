package paperclip.libs.org.apache.commons.compress.compressors;

import java.io.OutputStream;

public abstract class CompressorOutputStream extends OutputStream {
}
