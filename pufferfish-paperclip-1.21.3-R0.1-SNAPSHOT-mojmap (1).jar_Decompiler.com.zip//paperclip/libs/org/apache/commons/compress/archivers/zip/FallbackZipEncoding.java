package paperclip.libs.org.apache.commons.compress.archivers.zip;

import java.io.IOException;
import java.nio.ByteBuffer;

class FallbackZipEncoding implements ZipEncoding {
   private final String charset;

   public FallbackZipEncoding() {
      this.charset = null;
   }

   public FallbackZipEncoding(String charset) {
      this.charset = charset;
   }

   public boolean canEncode(String name) {
      return true;
   }

   public ByteBuffer encode(String name) throws IOException {
      return this.charset == null ? ByteBuffer.wrap(name.getBytes()) : ByteBuffer.wrap(name.getBytes(this.charset));
   }

   public String decode(byte[] data) throws IOException {
      return this.charset == null ? new String(data) : new String(data, this.charset);
   }
}
