package paperclip.libs.org.apache.commons.compress.compressors;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
import paperclip.libs.org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import paperclip.libs.org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import paperclip.libs.org.apache.commons.compress.compressors.pack200.Pack200CompressorInputStream;
import paperclip.libs.org.apache.commons.compress.compressors.pack200.Pack200CompressorOutputStream;
import paperclip.libs.org.apache.commons.compress.compressors.xz.XZCompressorInputStream;
import paperclip.libs.org.apache.commons.compress.compressors.xz.XZCompressorOutputStream;
import paperclip.libs.org.apache.commons.compress.compressors.xz.XZUtils;

public class CompressorStreamFactory {
   public static final String BZIP2 = "bzip2";
   public static final String GZIP = "gz";
   public static final String PACK200 = "pack200";
   public static final String XZ = "xz";
   private boolean decompressConcatenated = false;

   public void setDecompressConcatenated(boolean decompressConcatenated) {
      this.decompressConcatenated = decompressConcatenated;
   }

   public CompressorInputStream createCompressorInputStream(InputStream in) throws CompressorException {
      if (in == null) {
         throw new IllegalArgumentException("Stream must not be null.");
      } else if (!in.markSupported()) {
         throw new IllegalArgumentException("Mark is not supported.");
      } else {
         byte[] signature = new byte[12];
         in.mark(signature.length);

         try {
            int signatureLength = in.read(signature);
            in.reset();
            if (BZip2CompressorInputStream.matches(signature, signatureLength)) {
               return new BZip2CompressorInputStream(in, this.decompressConcatenated);
            }

            if (GzipCompressorInputStream.matches(signature, signatureLength)) {
               return new GzipCompressorInputStream(in, this.decompressConcatenated);
            }

            if (XZUtils.isXZCompressionAvailable() && XZCompressorInputStream.matches(signature, signatureLength)) {
               return new XZCompressorInputStream(in, this.decompressConcatenated);
            }

            if (Pack200CompressorInputStream.matches(signature, signatureLength)) {
               return new Pack200CompressorInputStream(in);
            }
         } catch (IOException var4) {
            throw new CompressorException("Failed to detect Compressor from InputStream.", var4);
         }

         throw new CompressorException("No Compressor found for the stream signature.");
      }
   }

   public CompressorInputStream createCompressorInputStream(String name, InputStream in) throws CompressorException {
      if (name != null && in != null) {
         try {
            if ("gz".equalsIgnoreCase(name)) {
               return new GzipCompressorInputStream(in);
            }

            if ("bzip2".equalsIgnoreCase(name)) {
               return new BZip2CompressorInputStream(in);
            }

            if ("xz".equalsIgnoreCase(name)) {
               return new XZCompressorInputStream(in);
            }

            if ("pack200".equalsIgnoreCase(name)) {
               return new Pack200CompressorInputStream(in);
            }
         } catch (IOException var4) {
            throw new CompressorException("Could not create CompressorInputStream.", var4);
         }

         throw new CompressorException("Compressor: " + name + " not found.");
      } else {
         throw new IllegalArgumentException("Compressor name and stream must not be null.");
      }
   }

   public CompressorOutputStream createCompressorOutputStream(String name, OutputStream out) throws CompressorException {
      if (name != null && out != null) {
         try {
            if ("gz".equalsIgnoreCase(name)) {
               return new GzipCompressorOutputStream(out);
            }

            if ("bzip2".equalsIgnoreCase(name)) {
               return new BZip2CompressorOutputStream(out);
            }

            if ("xz".equalsIgnoreCase(name)) {
               return new XZCompressorOutputStream(out);
            }

            if ("pack200".equalsIgnoreCase(name)) {
               return new Pack200CompressorOutputStream(out);
            }
         } catch (IOException var4) {
            throw new CompressorException("Could not create CompressorOutputStream", var4);
         }

         throw new CompressorException("Compressor: " + name + " not found.");
      } else {
         throw new IllegalArgumentException("Compressor name and stream must not be null.");
      }
   }
}
