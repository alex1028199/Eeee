package paperclip.libs.org.apache.commons.compress.archivers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import paperclip.libs.org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import paperclip.libs.org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import paperclip.libs.org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import paperclip.libs.org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import paperclip.libs.org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import paperclip.libs.org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import paperclip.libs.org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import paperclip.libs.org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import paperclip.libs.org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import paperclip.libs.org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import paperclip.libs.org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;

public class ArchiveStreamFactory {
   public static final String AR = "ar";
   public static final String CPIO = "cpio";
   public static final String DUMP = "dump";
   public static final String JAR = "jar";
   public static final String TAR = "tar";
   public static final String ZIP = "zip";
   private String entryEncoding = null;

   public String getEntryEncoding() {
      return this.entryEncoding;
   }

   public void setEntryEncoding(String entryEncoding) {
      this.entryEncoding = entryEncoding;
   }

   public ArchiveInputStream createArchiveInputStream(String archiverName, InputStream in) throws ArchiveException {
      if (archiverName == null) {
         throw new IllegalArgumentException("Archivername must not be null.");
      } else if (in == null) {
         throw new IllegalArgumentException("InputStream must not be null.");
      } else if ("ar".equalsIgnoreCase(archiverName)) {
         return new ArArchiveInputStream(in);
      } else if ("zip".equalsIgnoreCase(archiverName)) {
         return this.entryEncoding != null ? new ZipArchiveInputStream(in, this.entryEncoding) : new ZipArchiveInputStream(in);
      } else if ("tar".equalsIgnoreCase(archiverName)) {
         return this.entryEncoding != null ? new TarArchiveInputStream(in, this.entryEncoding) : new TarArchiveInputStream(in);
      } else if ("jar".equalsIgnoreCase(archiverName)) {
         return new JarArchiveInputStream(in);
      } else if ("cpio".equalsIgnoreCase(archiverName)) {
         return new CpioArchiveInputStream(in);
      } else if ("dump".equalsIgnoreCase(archiverName)) {
         return new DumpArchiveInputStream(in);
      } else {
         throw new ArchiveException("Archiver: " + archiverName + " not found.");
      }
   }

   public ArchiveOutputStream createArchiveOutputStream(String archiverName, OutputStream out) throws ArchiveException {
      if (archiverName == null) {
         throw new IllegalArgumentException("Archivername must not be null.");
      } else if (out == null) {
         throw new IllegalArgumentException("OutputStream must not be null.");
      } else if ("ar".equalsIgnoreCase(archiverName)) {
         return new ArArchiveOutputStream(out);
      } else if ("zip".equalsIgnoreCase(archiverName)) {
         ZipArchiveOutputStream zip = new ZipArchiveOutputStream(out);
         if (this.entryEncoding != null) {
            zip.setEncoding(this.entryEncoding);
         }

         return zip;
      } else if ("tar".equalsIgnoreCase(archiverName)) {
         return this.entryEncoding != null ? new TarArchiveOutputStream(out, this.entryEncoding) : new TarArchiveOutputStream(out);
      } else if ("jar".equalsIgnoreCase(archiverName)) {
         return new JarArchiveOutputStream(out);
      } else if ("cpio".equalsIgnoreCase(archiverName)) {
         return new CpioArchiveOutputStream(out);
      } else {
         throw new ArchiveException("Archiver: " + archiverName + " not found.");
      }
   }

   public ArchiveInputStream createArchiveInputStream(InputStream in) throws ArchiveException {
      if (in == null) {
         throw new IllegalArgumentException("Stream must not be null.");
      } else if (!in.markSupported()) {
         throw new IllegalArgumentException("Mark is not supported.");
      } else {
         byte[] signature = new byte[12];
         in.mark(signature.length);

         try {
            int signatureLength = in.read(signature);
            in.reset();
            if (ZipArchiveInputStream.matches(signature, signatureLength)) {
               if (this.entryEncoding != null) {
                  return new ZipArchiveInputStream(in, this.entryEncoding);
               }

               return new ZipArchiveInputStream(in);
            }

            if (JarArchiveInputStream.matches(signature, signatureLength)) {
               return new JarArchiveInputStream(in);
            }

            if (ArArchiveInputStream.matches(signature, signatureLength)) {
               return new ArArchiveInputStream(in);
            }

            if (CpioArchiveInputStream.matches(signature, signatureLength)) {
               return new CpioArchiveInputStream(in);
            }

            byte[] dumpsig = new byte[32];
            in.mark(dumpsig.length);
            signatureLength = in.read(dumpsig);
            in.reset();
            if (DumpArchiveInputStream.matches(dumpsig, signatureLength)) {
               return new DumpArchiveInputStream(in);
            }

            byte[] tarheader = new byte[512];
            in.mark(tarheader.length);
            signatureLength = in.read(tarheader);
            in.reset();
            if (TarArchiveInputStream.matches(tarheader, signatureLength)) {
               if (this.entryEncoding != null) {
                  return new TarArchiveInputStream(in, this.entryEncoding);
               }

               return new TarArchiveInputStream(in);
            }

            if (signatureLength >= 512) {
               TarArchiveInputStream tais = null;

               TarArchiveInputStream var7;
               try {
                  tais = new TarArchiveInputStream(new ByteArrayInputStream(tarheader));
                  if (!tais.getNextTarEntry().isCheckSumOK()) {
                     throw new ArchiveException("No Archiver found for the stream signature");
                  }

                  var7 = new TarArchiveInputStream(in);
               } catch (Exception var19) {
                  throw new ArchiveException("No Archiver found for the stream signature");
               } finally {
                  if (tais != null) {
                     try {
                        tais.close();
                     } catch (IOException var18) {
                     }
                  }

               }

               return var7;
            }
         } catch (IOException var21) {
            throw new ArchiveException("Could not use reset and mark operations.", var21);
         }

         throw new ArchiveException("No Archiver found for the stream signature");
      }
   }
}
