package paperclip.libs.io.sigpipe.jbsdiff.ui;

// $FF: synthetic class
interface package-info {
}
