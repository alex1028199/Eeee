package paperclip.libs.io.sigpipe.jbsdiff;

public interface DiffSettings {
   String getCompression();

   int[] sort(byte[] var1);
}
