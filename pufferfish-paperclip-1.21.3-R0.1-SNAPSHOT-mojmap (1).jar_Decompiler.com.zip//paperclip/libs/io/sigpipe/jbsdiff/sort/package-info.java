package paperclip.libs.io.sigpipe.jbsdiff.sort;

// $FF: synthetic class
interface package-info {
}
