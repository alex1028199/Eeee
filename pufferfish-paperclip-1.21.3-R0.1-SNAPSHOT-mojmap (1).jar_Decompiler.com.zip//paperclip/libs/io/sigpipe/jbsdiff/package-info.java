package paperclip.libs.io.sigpipe.jbsdiff;

// $FF: synthetic class
interface package-info {
}
